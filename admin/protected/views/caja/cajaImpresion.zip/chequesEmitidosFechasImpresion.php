<?php
$model = new Cheque();

$desde = $caja->fechaDesde!=null?LGHelper::functions()->undisplayFecha($caja->fechaDesde):null;
$hasta = $caja->fechaHasta!=null?LGHelper::functions()->undisplayFecha($caja->fechaHasta):null;

$this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'cheque-grid',
	'dataProvider'=>$model->searchEntreFechas($desde, $hasta),
	//'filter'=>$model,
	'enableSorting'  => false,
	'columns'=>array(
        'serie',
		'Numero',
		'id_obra',
				array (
						'name' => 'id_cuenta_banco',
						'value' => '$data->cuentaBanco->descripcion',
						'filter' => CHtml::listData ( CuentaBanco::model ()->findAll ( array (
								'order' => 'nombre' 
						) ), 'id_cuenta_banco', 'descripcion' ) 
				),
		'FechaEmision',
		'FechaPago',
		'Importe',
		
	),
)); ?>